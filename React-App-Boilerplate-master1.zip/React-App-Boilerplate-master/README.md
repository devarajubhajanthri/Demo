# React App Boilerplate

After downloading the project open the cmd/trminal and go to the project directory. Once you are in the project directory run the command given below. 

(Make sure you have installed node and create-react-app previously)

    npm install
