import React, { Component } from "react";

class Logo extends Component {

    render() {
      return (
          <div>LOGO</div>
      );
    }
}


export default Logo;
